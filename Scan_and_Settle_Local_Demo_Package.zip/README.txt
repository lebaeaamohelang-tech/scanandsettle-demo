SCAN & SETTLE — LOCAL DEMO

Quick use on Android:
1. Download Scan_and_Settle_Local_Demo.html.
2. Open it from Downloads using Chrome or another browser.
3. If Android asks, choose a browser. If it opens as text, use the file manager's "Open with" browser option.
4. Use the Customer experience / Restaurant-Hotel toggle.
5. Try buttons, status changes, vouchers, mini-game, service requests, and promotions.

This is a self-contained local HTML prototype. It does not connect to a real restaurant POS, payment processor, Google Reviews, live advertising, or online backend. Demo state may persist in the browser's local storage. Clear/reset browser site data to reset it.

Included source:
- Scan_and_Settle_Local_Demo.html

This is not an APK or a Play Store app yet. It is an offline-capable local browser prototype, the quickest way to test the interface on a phone.
